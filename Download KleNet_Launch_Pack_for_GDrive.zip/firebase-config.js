const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "klenet.firebaseapp.com",
  projectId: "klenet",
  storageBucket: "klenet.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "YOUR_MEASUREMENT_ID"
};

export default firebaseConfig;
